import axios from 'axios';

const API_BASE_URL = 'http://localhost:8082/api';

// Configure axios instance
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Get current visitor count and statuses
export const getCurrentCount = async () => {
  try {
    const response = await apiClient.get('/counter/current');
    return response.data;
  } catch (error) {
    console.error('Error fetching current count:', error);
    throw error;
  }
};

// Get max limit setting
export const getMaxLimit = async () => {
  try {
    const response = await apiClient.get('/counter/maxlimit');
    return response.data;
  } catch (error) {
    console.error('Error fetching max limit:', error);
    throw error;
  }
};

// Update max limit setting
export const setMaxLimit = async (limit) => {
  try {
    const response = await apiClient.post('/counter/maxlimit', { maxLimit: limit });
    return response.data;
  } catch (error) {
    console.error('Error setting max limit:', error);
    throw error;
  }
};

// Control alarm
export const controlAlarm = async (status) => {
  try {
    const response = await apiClient.post('/counter/alarm', { status });
    return response.data;
  } catch (error) {
    console.error('Error controlling alarm:', error);
    throw error;
  }
};

// Control light
export const controlLight = async (status) => {
  try {
    const response = await apiClient.post('/counter/light', { status });
    return response.data;
  } catch (error) {
    console.error('Error controlling light:', error);
    throw error;
  }
};

// Get historical data (day, week, year)
export const getHistoricalData = async (timeframe) => {
  try {
    const response = await apiClient.get(`/counter/history/${timeframe}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching ${timeframe} history:`, error);
    throw error;
  }
};

// Connect to the embedded system
export const connectToEmbeddedSystem = async (config) => {
  try {
    const response = await apiClient.post('/embedded/connect', config);
    return response.data;
  } catch (error) {
    console.error('Error connecting to embedded system:', error);
    throw error;
  }
};

// Check connection status to embedded system
export const getEmbeddedConnectionStatus = async () => {
  try {
    const response = await apiClient.get('/embedded/status');
    return response.data;
  } catch (error) {
    console.error('Error checking embedded connection status:', error);
    throw error;
  }
};
