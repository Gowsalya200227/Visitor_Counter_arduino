import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const DigitCounter = ({ 
  digits, 
  title, 
  isEditable = false, 
  handleDigitChange = null,
  className = "" 
}) => {
  // Convert number to array of digits
  const digitsArray = digits.toString().padStart(4, '0').split('');
  
  const incrementDigit = (index) => {
    if (!isEditable || !handleDigitChange) return;
    
    const digit = parseInt(digitsArray[index], 10);
    const newDigit = (digit + 1) % 10;
    handleDigitChange(index, newDigit);
  };
  
  const decrementDigit = (index) => {
    if (!isEditable || !handleDigitChange) return;
    
    const digit = parseInt(digitsArray[index], 10);
    const newDigit = (digit - 1 + 10) % 10;
    handleDigitChange(index, newDigit);
  };

  // Animation variants for digit
  const digitVariants = {
    initial: { opacity: 0, y: 10 },
    animate: (index) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.05,
        duration: 0.3,
        type: "spring",
        stiffness: 300,
      },
    }),
    exit: { opacity: 0, y: -10 },
    hover: { scale: 1.05, boxShadow: "0 4px 8px rgba(0,0,0,0.1)" },
    tap: { scale: 0.95 }
  };

  // Animation variants for buttons
  const buttonVariants = {
    hover: { scale: 1.2, backgroundColor: "#fff", boxShadow: "0 2px 5px rgba(0,0,0,0.2)" },
    tap: { scale: 0.9 }
  };
  
  return (
    <motion.div 
      className={`${title ? "bg-primary p-6 rounded-lg mb-4" : ""} ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {title && (
        <motion.div 
          className="text-white mb-4 text-xl font-semibold text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {title}
        </motion.div>
      )}
      <div className="flex space-x-3 justify-center">
        <AnimatePresence mode="wait">
          {digitsArray.map((digit, index) => (
            <motion.div 
              key={index} 
              className="relative"
              initial="initial"
              animate="animate"
              exit="exit"
              custom={index}
              variants={digitVariants}
            >
              {isEditable && (
                <motion.button
                  onClick={() => incrementDigit(index)}
                  className="absolute -top-6 left-0 right-0 mx-auto text-lg text-primary w-6 h-6 flex items-center justify-center bg-white rounded-full shadow-sm"
                  aria-label="Increment"
                  whileHover="hover"
                  whileTap="tap"
                  variants={buttonVariants}
                >
                  ▲
                </motion.button>
              )}
              <motion.div 
                className={`w-12 h-14 ${isEditable ? 'bg-white' : 'bg-white'} rounded-md shadow-sm flex items-center justify-center text-2xl font-semibold ${isEditable ? 'text-primary' : 'text-gray-800'} border ${isEditable ? 'border-primary border-opacity-30' : 'border-gray-200'}`}
                whileHover={isEditable ? "hover" : {}}
                whileTap={isEditable ? "tap" : {}}
                variants={isEditable ? digitVariants : {}}
                transition={{ type: "spring", stiffness: 500 }}
              >
                {digit}
              </motion.div>
              {isEditable && (
                <motion.button
                  onClick={() => decrementDigit(index)}
                  className="absolute -bottom-6 left-0 right-0 mx-auto text-lg text-primary w-6 h-6 flex items-center justify-center bg-white rounded-full shadow-sm"
                  aria-label="Decrement"
                  whileHover="hover"
                  whileTap="tap"
                  variants={buttonVariants}
                >
                  ▼
                </motion.button>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default DigitCounter;
