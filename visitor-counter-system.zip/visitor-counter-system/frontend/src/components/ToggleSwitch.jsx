import React from 'react';
import { motion } from 'framer-motion';

const ToggleSwitch = ({ isOn, handleToggle, label }) => {
  // Define animation variants with enhanced visual effects
  const switchVariants = {
    on: { 
      backgroundColor: '#4B8BA7', 
      boxShadow: '0 0 12px rgba(75, 139, 167, 0.6)' 
    },
    off: { 
      backgroundColor: '#d1d5db', 
      boxShadow: '0 0 5px rgba(209, 213, 219, 0.3)' 
    }
  };

  const knobVariants = {
    on: { 
      x: 22, 
      backgroundColor: '#ffffff',
      boxShadow: '0 0 8px rgba(0, 0, 0, 0.3)'
    },
    off: { 
      x: 2, 
      backgroundColor: '#ffffff',
      boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)'
    },
    hover: { 
      scale: 1.1,
      boxShadow: '0 0 10px rgba(0, 0, 0, 0.3)'
    },
    tap: { 
      scale: 0.9
    }
  };
  
  // Text variants for smoother animation
  const textVariants = {
    on: { opacity: 1, y: 0 },
    off: { opacity: 0.7, y: 0 }
  };
  
  // Handle manual toggle click - this will toggle the switch
  const handleClick = () => {
    handleToggle(!isOn); // Toggle the current state
  };

  return (
    <motion.div 
      className="flex flex-col items-center justify-center"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {label && 
        <motion.p 
          className="text-lg font-semibold text-center mb-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {label}
        </motion.p>
      }
      <div className="relative inline-block w-16 h-9 transition duration-200 ease-in-out">
        <input 
          type="checkbox" 
          className="opacity-0 w-0 h-0"
          checked={isOn} 
          onChange={() => {}} // Empty onChange as we're handling click directly
          id={`switch-${label || Math.random().toString(36).substring(7)}`}
        />
        <motion.label 
          htmlFor={`switch-${label || Math.random().toString(36).substring(7)}`}
          className="absolute top-0 left-0 right-0 bottom-0 flex items-center 
                    rounded-full cursor-pointer border-2 border-transparent"
          variants={switchVariants}
          initial={isOn ? "on" : "off"}
          animate={isOn ? "on" : "off"}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
          onClick={handleClick} // Add click handler directly to the label
        >
          {/* Add status indicators inside the toggle */}
          <motion.span 
            className="absolute left-1.5 text-xs font-bold text-white select-none"
            animate={{ opacity: isOn ? 1 : 0 }}
            transition={{ duration: 0.2 }}
          >
            I
          </motion.span>
          <motion.span 
            className="absolute right-1.5 text-xs font-bold text-gray-400 select-none"
            animate={{ opacity: isOn ? 0 : 1 }}
            transition={{ duration: 0.2 }}
          >
            O
          </motion.span>
          <motion.span 
            className="absolute h-7 w-7 rounded-full bg-white"
            variants={knobVariants}
            initial={isOn ? "on" : "off"}
            animate={isOn ? "on" : "off"}
            whileHover="hover"
            whileTap="tap"
            transition={{ type: "spring", stiffness: 500, damping: 25 }}
          />
        </motion.label>
      </div>
      <motion.div
        className="mt-1 text-center"
        variants={textVariants}
        initial={isOn ? "on" : "off"}
        animate={isOn ? "on" : "off"}
        transition={{ duration: 0.3 }}
      >
        <motion.span 
          className={`text-sm font-medium ${isOn ? 'text-primary' : 'text-gray-500'}`}
          layout
        >
          {isOn ? "ON" : "OFF"}
        </motion.span>
      </motion.div>
    </motion.div>
  );
};

export default ToggleSwitch;
