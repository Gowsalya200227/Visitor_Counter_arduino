import React, { useRef, useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import { motion } from 'framer-motion';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import zoomPlugin from 'chartjs-plugin-zoom';
import { FaSearchPlus, FaSearchMinus, FaUndoAlt, FaTimes, FaExpand } from 'react-icons/fa';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  zoomPlugin
);

const LineChart = ({ data, timeframe }) => {
  const chartRef = useRef(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // Generate labels based on timeframe
  const generateLabels = () => {
    switch (timeframe) {
      case 'day':
        return Array.from({ length: 24 }, (_, i) => `${i}:00`);
      case 'week':
        return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      case 'year':
        return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      default:
        return [];
    }
  };

  // Reset zoom when timeframe changes
  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.resetZoom();
      setDetailedData(false); // Reset detailed data when timeframe changes
    }
  }, [timeframe]);
  
  // Add event listener for ESC key to exit fullscreen
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isFullscreen) {
        toggleFullscreen();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen]);

  const resetZoom = () => {
    if (chartRef.current) {
      chartRef.current.resetZoom();
    }
  };

  const zoomIn = () => {
    if (chartRef.current) {
      chartRef.current.zoom(1.1);
    }
  };

  const zoomOut = () => {
    if (chartRef.current) {
      chartRef.current.zoom(0.9);
    }
  };

  // Expanded state for detailed data view
  const [detailedData, setDetailedData] = useState(false);
  
  const toggleFullscreen = () => {
    const newFullscreenState = !isFullscreen;
    setIsFullscreen(newFullscreenState);
    
    // Reset zoom and detailed data when exiting fullscreen
    if (!newFullscreenState && chartRef.current) {
      setDetailedData(false); // Reset detailed data flag
      
      // Use a slightly longer delay to ensure DOM is updated
      setTimeout(() => {
        if (chartRef.current) {
          // Reset zoom level
          chartRef.current.resetZoom();
          
          // Force a complete re-render
          const chart = chartRef.current.getChart();
          chart.update('reset'); // Force complete redraw
        }
      }, 300); // Longer delay to ensure DOM has updated
    }
  };

  // Default options for the chart
  // Function to get detailed labels based on timeframe and zoom level
  const getDetailedLabels = (timeframe, index) => {
    switch(timeframe) {
      case 'day':
        // For day view, show hours with minutes
        return `${Math.floor(index / 4)}:${(index % 4) * 15 === 0 ? '00' : (index % 4) * 15}`;
      case 'week':
        // For week view, show day with hours
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const dayIndex = Math.floor(index / 24);
        const hour = index % 24;
        return `${days[dayIndex]} ${hour}:00`;
      case 'year':
        // For year view, show month with day
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const monthIndex = Math.floor(index / 30);
        const day = (index % 30) + 1;
        return `${months[monthIndex]} ${day}`;
      default:
        return index.toString();
    }
  };
  
  // Detect zoom state
  const handleZoom = (chart) => {
    // Only show detailed data when user has zoomed in
    const meta = chart.getDatasetMeta(0);
    const range = meta._xScale.max - meta._xScale.min;
    const fullRange = chart.scales.x.max - chart.scales.x.min;
    
    // Calculate zoom level percentage (0-100)
    const zoomPercentage = 100 - ((range / fullRange) * 100);
    
    // Only show detailed data if zoomed in at least 25% (showing fewer points)
    const isZoomedIn = zoomPercentage > 25;
    
    // Only update state if it's different to avoid unnecessary re-renders
    if (isZoomedIn !== detailedData) {
      setDetailedData(isZoomedIn);
      
      // Force chart update when detail level changes
      if (chartRef.current) {
        const chart = chartRef.current.getChart();
        chart.update();
      }
    }
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'index',
      intersect: false,
    },
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        titleColor: '#4B8BA7',
        bodyColor: '#4B8BA7',
        borderColor: '#4B8BA7',
        borderWidth: 1,
        padding: 10,
        displayColors: false,
        callbacks: {
          title: function(context) {
            if (timeframe === 'day' && detailedData) {
              // Show more detailed time info (with minutes) only when zoomed in for day view
              const hour = Math.floor(context[0].dataIndex / 4);
              const minutes = (context[0].dataIndex % 4) * 15;
              return `${hour}:${minutes === 0 ? '00' : minutes}`;
            } else if (timeframe === 'day') {
              // For day view but not zoomed in, show only hours
              return `${context[0].dataIndex}:00`;
            } else {
              // For other timeframes, use standard labels
              return `${generateLabels()[context[0].dataIndex]}`;
            }
          },
          label: function(context) {
            return `Visitors: ${context.raw}`;
          }
        }
      },
      zoom: {
        pan: {
          enabled: true,
          mode: 'x',
          threshold: 5,
          onPan: ({chart}) => handleZoom(chart)
        },
        zoom: {
          wheel: {
            enabled: true,
          },
          pinch: {
            enabled: true,
          },
          mode: 'x',
          drag: {
            enabled: true,
            backgroundColor: 'rgba(75, 139, 167, 0.1)',
            borderColor: 'rgba(75, 139, 167, 0.3)',
          },
          onZoom: ({chart}) => handleZoom(chart)
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(75, 139, 167, 0.1)',
        },
        ticks: {
          color: '#4B8BA7',
          font: {
            size: 10
          }
        },
        title: {
          display: false,
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: '#4B8BA7',
          font: {
            size: 10
          }
        },
        title: {
          display: false,
        },
      },
    },
    elements: {
      line: {
        tension: 0.4,
        borderWidth: 2,
        borderColor: '#4B8BA7',
        fill: 'start',
        backgroundColor: 'rgba(75, 139, 167, 0.1)',
      },
      point: {
        radius: detailedData ? 1 : 3, // Smaller points when showing detailed data
        borderColor: '#4B8BA7',
        backgroundColor: '#fff',
        borderWidth: 2,
        hoverRadius: 5,
      },
    },
    transitions: {
      zoom: {
        animation: {
          duration: 1000,
          easing: 'easeOutCubic'
        }
      }
    }
  };

  // Generate more detailed data for zooming
  const generateDetailedData = () => {
    // Create more granular data based on timeframe
    let detailedLabels = [];
    let detailedData = [];
    
    switch(timeframe) {
      case 'day':
        if (detailedData) {
          // Only show 15-minute intervals when zoomed in (96 points instead of 24)
          detailedLabels = Array.from({ length: 96 }, (_, i) => {
            const hour = Math.floor(i / 4);
            const minutes = (i % 4) * 15;
            return `${hour}:${minutes === 0 ? '00' : minutes}`;
          });
          
          // Interpolate the data to match the detailed labels
          if (data && data.length) {
            detailedData = Array.from({ length: 96 }, (_, i) => {
              const hourIndex = Math.floor(i / 4);
              const nextHourIndex = (hourIndex + 1) % 24;
              const hourFraction = (i % 4) / 4;
              const hourValue = data[hourIndex] || 0;
              const nextHourValue = data[nextHourIndex] || 0;
              // Linear interpolation between hour values
              return Math.round(hourValue + (nextHourValue - hourValue) * hourFraction);
            });
          } else {
            detailedData = Array(96).fill(0);
          }
        } else {
          // Default view - just show hourly data
          detailedLabels = Array.from({ length: 24 }, (_, i) => `${i}:00`);
          detailedData = data || Array(24).fill(0);
        }
        break;
      case 'week':
        // For week view, break down to hourly data (168 points instead of 7)
        detailedLabels = Array.from({ length: 168 }, (_, i) => getDetailedLabels('week', i));
        // Interpolate the data
        if (data && data.length) {
          detailedData = Array.from({ length: 168 }, (_, i) => {
            const dayIndex = Math.floor(i / 24);
            const dayValue = data[dayIndex] || 0;
            // Create variations throughout the day based on the day's value
            const hourMultiplier = 0.7 + 0.6 * Math.sin((i % 24) / 24 * Math.PI); // Higher during day, lower at night
            return Math.round(dayValue * hourMultiplier);
          });
        } else {
          detailedData = Array(168).fill(0);
        }
        break;
      case 'year':
        // For year view, break down to daily data (365 points instead of 12)
        detailedLabels = Array.from({ length: 365 }, (_, i) => getDetailedLabels('year', i));
        // Interpolate the data
        if (data && data.length) {
          detailedData = Array.from({ length: 365 }, (_, i) => {
            const monthIndex = Math.floor(i / 30);
            const nextMonthIndex = (monthIndex + 1) % 12;
            const monthFraction = (i % 30) / 30;
            const monthValue = data[monthIndex] || 0;
            const nextMonthValue = data[nextMonthIndex] || 0;
            // Linear interpolation between month values
            return Math.round(monthValue + (nextMonthValue - monthValue) * monthFraction);
          });
        } else {
          detailedData = Array(365).fill(0);
        }
        break;
      default:
        detailedLabels = generateLabels();
        detailedData = data || Array(generateLabels().length).fill(0);
    }
    
    return { labels: detailedLabels, data: detailedData };
  };
  
  // Get the appropriate data based on detail level
  const detailedDataset = generateDetailedData();

  const chartData = {
    // Use detailed labels when appropriate, or fall back to standard labels
    labels: detailedDataset.labels,
    datasets: [
      {
        label: 'Visitors',
        data: detailedDataset.data,
        borderColor: '#4B8BA7',
        backgroundColor: 'rgba(75, 139, 167, 0.1)',
        pointRadius: detailedData ? 2 : 3, // Smaller points when showing detailed data
        pointHoverRadius: 5,
      },
    ],
  };

  // Add orientation detection
  const [isLandscape, setIsLandscape] = useState(
    typeof window !== 'undefined' && window.matchMedia && 
    window.matchMedia('(orientation: landscape)').matches
  );

  // Update orientation on change
  useEffect(() => {
    const handleOrientationChange = () => {
      if (typeof window !== 'undefined' && window.matchMedia) {
        setIsLandscape(window.matchMedia('(orientation: landscape)').matches);
      }
    };

    window.addEventListener('resize', handleOrientationChange);
    return () => window.removeEventListener('resize', handleOrientationChange);
  }, []);

  // Enhanced container style with landscape mode support
  const chartContainerStyle = isFullscreen ? {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1000,
    backgroundColor: 'white',
    padding: isLandscape ? '10px 20px' : '20px',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
  } : {
    height: '250px',
    position: 'relative',
  };

  return (
    <motion.div 
      style={chartContainerStyle}
      layout
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <div className={`flex ${isFullscreen ? 'justify-between' : 'justify-end'} mb-2 ${isFullscreen ? 'px-2' : ''}`}>
        {isFullscreen && (
          <motion.button 
            onClick={toggleFullscreen} 
            className="p-2 rounded-full bg-red-500 text-white shadow-md"
            whileHover={{ scale: 1.1, backgroundColor: '#e53e3e' }}
            whileTap={{ scale: 0.9 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <FaTimes className="w-4 h-4" />
          </motion.button>
        )}
        
        <div className="flex space-x-2">
          <motion.button 
            onClick={zoomIn} 
            className="p-2 rounded-full bg-primary text-white shadow-sm"
            whileHover={{ scale: 1.1, boxShadow: '0 0 8px rgba(75, 139, 167, 0.6)' }}
            whileTap={{ scale: 0.9 }}
          >
            <FaSearchPlus className="w-4 h-4" />
          </motion.button>
          <motion.button 
            onClick={zoomOut} 
            className="p-2 rounded-full bg-primary text-white shadow-sm"
            whileHover={{ scale: 1.1, boxShadow: '0 0 8px rgba(75, 139, 167, 0.6)' }}
            whileTap={{ scale: 0.9 }}
          >
            <FaSearchMinus className="w-4 h-4" />
          </motion.button>
          <motion.button 
            onClick={resetZoom} 
            className="p-2 rounded-full bg-primary text-white shadow-sm"
            whileHover={{ scale: 1.1, boxShadow: '0 0 8px rgba(75, 139, 167, 0.6)' }}
            whileTap={{ scale: 0.9 }}
          >
            <FaUndoAlt className="w-4 h-4" />
          </motion.button>
          {!isFullscreen && (
            <motion.button 
              onClick={toggleFullscreen} 
              className="p-2 rounded-full bg-primary text-white shadow-sm"
              whileHover={{ scale: 1.1, boxShadow: '0 0 8px rgba(75, 139, 167, 0.6)' }}
              whileTap={{ scale: 0.9 }}
            >
              <FaExpand className="w-4 h-4" />
            </motion.button>
          )}
        </div>
      </div>
      
      <div className="flex-grow" style={{ 
        minHeight: isFullscreen 
          ? isLandscape 
            ? 'calc(100% - 60px)' 
            : 'calc(100% - 80px)' 
          : '230px' 
      }}>
        <Line ref={chartRef} options={options} data={chartData} />
      </div>
      
      {isFullscreen && (
        <motion.div 
          className="mt-2 text-center text-gray-500 text-sm"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <p>
            {detailedData 
              ? "Showing detailed data - zoom out to see overview" 
              : isLandscape 
                ? "Pinch/wheel to zoom for detailed data, drag to pan" 
                : "Rotate to landscape for better view"}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
};

export default LineChart;
