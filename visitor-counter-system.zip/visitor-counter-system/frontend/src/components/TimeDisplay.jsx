import React, { useState, useEffect } from 'react';

const TimeDisplay = () => {
  const [time, setTime] = useState({
    hours: '12',
    minutes: '00',
    ampm: 'PM'
  });

  useEffect(() => {
    // Update time initially
    updateTime();
    
    // Update time every minute
    const interval = setInterval(updateTime, 60000);
    
    return () => clearInterval(interval);
  }, []);

  const updateTime = () => {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours.toString() : '12';
    hours = hours.toString().padStart(2, '0');
    
    setTime({ hours, minutes, ampm });
  };

  return (
    <div className="bg-white p-4 rounded-lg my-4 shadow-sm">
      <div className="text-center font-semibold mb-2">Time</div>
      <div className="flex justify-center items-center space-x-1">
        {/* Hours */}
        <div className="counter-box bg-primary text-white">{time.hours[0]}</div>
        <div className="counter-box bg-primary text-white">{time.hours[1]}</div>
        <div className="text-lg font-bold">:</div>
        {/* Minutes */}
        <div className="counter-box bg-primary text-white">{time.minutes[0]}</div>
        <div className="counter-box bg-primary text-white">{time.minutes[1]}</div>
        <div className="text-lg font-bold">:</div>
        {/* AM/PM */}
        <div className="counter-box bg-primary text-white">{time.ampm[0]}</div>
        <div className="counter-box bg-primary text-white">{time.ampm[1]}</div>
      </div>
    </div>
  );
};

export default TimeDisplay;
