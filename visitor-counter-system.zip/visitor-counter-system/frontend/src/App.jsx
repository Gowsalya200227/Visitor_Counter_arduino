import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import HomePage from './pages/HomePage';
import HistoryPage from './pages/HistoryPage';
import { getEmbeddedConnectionStatus, connectToEmbeddedSystem } from './api/counterApi';
import { FaHome, FaChartLine } from 'react-icons/fa';
import './App.css';

function App() {
  const [isConnected, setIsConnected] = useState(false);
  const [connectionError, setConnectionError] = useState('');
  const [connectionConfig, setConnectionConfig] = useState({
    port: '/dev/ttyUSB0',
    baudRate: 9600
  });

  useEffect(() => {
    // Check connection status when app loads
    checkConnectionStatus();
  }, []);

  const checkConnectionStatus = async () => {
    try {
      const response = await getEmbeddedConnectionStatus();
      setIsConnected(response.connected);
    } catch (error) {
      console.error('Error checking connection status:', error);
      setIsConnected(false);
    }
  };

  const handleConnect = async () => {
    try {
      setConnectionError('');
      const response = await connectToEmbeddedSystem(connectionConfig);
      setIsConnected(response.connected);
    } catch (error) {
      console.error('Connection error:', error);
      setConnectionError('Failed to connect to the embedded system. Please check your settings and try again.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setConnectionConfig(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // If not connected, show connection form
  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-100">
        <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
          <h1 className="text-2xl font-bold text-primary mb-4 text-center">Visitor Counter System</h1>
          <p className="text-gray-600 mb-6 text-center">Connect to your embedded visitor counter device</p>
          
          {connectionError && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {connectionError}
            </div>
          )}
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              Serial Port
            </label>
            <input
              type="text"
              name="port"
              value={connectionConfig.port}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            />
            <p className="text-gray-500 text-xs mt-1">Example: /dev/ttyUSB0 (Linux/Mac) or COM3 (Windows)</p>
          </div>
          
          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              Baud Rate
            </label>
            <select
              name="baudRate"
              value={connectionConfig.baudRate}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            >
              <option value="9600">9600</option>
              <option value="115200">115200</option>
              <option value="57600">57600</option>
              <option value="38400">38400</option>
              <option value="19200">19200</option>
            </select>
          </div>
          
          <button
            onClick={handleConnect}
            className="w-full bg-primary hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          >
            Connect
          </button>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <AppContent isConnected={isConnected} />
    </Router>
  );
}

// Separate component for content to access location with useLocation hook
function AppContent({ isConnected }) {
  const location = useLocation();
  
  if (!isConnected) {
    return <ConnectionForm />;
  }
  
  return (
    <div className="visitor-counter-app h-screen max-h-screen overflow-hidden flex flex-col">
      <div className="flex-grow overflow-hidden">
        <AnimatePresence mode="wait">
          <Routes key={location.pathname} location={location}>
            <Route path="/" element={
              <motion.div
                className="h-full overflow-hidden"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
              >
                <HomePage />
              </motion.div>
            } />
            <Route path="/history" element={
              <motion.div
                className="h-full overflow-hidden"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <HistoryPage />
              </motion.div>
            } />
          </Routes>
        </AnimatePresence>
      </div>
      
      {/* Navigation */}
      <motion.nav 
        className="fixed bottom-0 left-0 right-0 bg-white shadow-lg p-3"
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ delay: 0.2, type: "spring", stiffness: 500, damping: 30 }}
      >
        <div className="flex justify-around">
          <Link to="/">
            <motion.div 
              className={`flex flex-col items-center ${location.pathname === '/' ? 'text-primary' : 'text-gray-600'}`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaHome className="h-6 w-6" />
              <span className="text-xs mt-1">Home</span>
            </motion.div>
          </Link>
          <Link to="/history">
            <motion.div 
              className={`flex flex-col items-center ${location.pathname === '/history' ? 'text-primary' : 'text-gray-600'}`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaChartLine className="h-6 w-6" />
              <span className="text-xs mt-1">History</span>
            </motion.div>
          </Link>
        </div>
      </motion.nav>
    </div>
  );
}

// Connection form component
function ConnectionForm() {
  const [connectionConfig, setConnectionConfig] = useState({
    port: '/dev/ttyUSB0',
    baudRate: 9600
  });
  const [connectionError, setConnectionError] = useState('');

  const handleConnect = async () => {
    try {
      setConnectionError('');
      const response = await connectToEmbeddedSystem(connectionConfig);
      if (!response.connected) {
        setConnectionError('Failed to connect. Please check your settings.');
      }
      window.location.reload(); // Reload to update connection status
    } catch (error) {
      console.error('Connection error:', error);
      setConnectionError('Failed to connect to the embedded system. Please check your settings and try again.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setConnectionConfig(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <motion.div 
      className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-100"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div 
        className="w-full max-w-md p-6 bg-white rounded-lg shadow-md"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold text-primary mb-4 text-center">Visitor Counter System</h1>
        <p className="text-gray-600 mb-6 text-center">Connect to your embedded visitor counter device</p>
        
        {connectionError && (
          <motion.div 
            className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {connectionError}
          </motion.div>
        )}
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Serial Port
          </label>
          <input
            type="text"
            name="port"
            value={connectionConfig.port}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          />
          <p className="text-gray-500 text-xs mt-1">Example: /dev/ttyUSB0 (Linux/Mac) or COM3 (Windows)</p>
        </div>
        
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Baud Rate
          </label>
          <select
            name="baudRate"
            value={connectionConfig.baudRate}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          >
            <option value="9600">9600</option>
            <option value="115200">115200</option>
            <option value="57600">57600</option>
            <option value="38400">38400</option>
            <option value="19200">19200</option>
          </select>
        </div>
        
        <motion.button
          onClick={handleConnect}
          className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          whileHover={{ scale: 1.03, backgroundColor: "#3B7A96" }}
          whileTap={{ scale: 0.97 }}
          transition={{ duration: 0.2 }}
        >
          Connect
        </motion.button>
      </motion.div>
    </motion.div>
  );
}

export default App;