import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import LineChart from '../components/LineChart';
import DigitCounter from '../components/DigitCounter';
import TimeDisplay from '../components/TimeDisplay';
import { getHistoricalData, getCurrentCount } from '../api/counterApi';
import { FaUsers, FaChartLine } from 'react-icons/fa';

const HistoryPage = () => {
  const [activeTab, setActiveTab] = useState('week');
  const [historicalData, setHistoricalData] = useState([]);
  const [visitorCount, setVisitorCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load data when the page loads or when the tab changes
    fetchData();
    
    // Set up polling for real-time updates
    const interval = setInterval(() => {
      fetchCurrentCount();
    }, 3000);
    
    return () => clearInterval(interval);
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [historyResponse, countResponse] = await Promise.all([
        getHistoricalData(activeTab),
        getCurrentCount()
      ]);
      
      setHistoricalData(historyResponse.data);
      setVisitorCount(countResponse.count);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  const fetchCurrentCount = async () => {
    try {
      const response = await getCurrentCount();
      setVisitorCount(response.count);
    } catch (error) {
      console.error('Error fetching current count:', error);
    }
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }

  return (
    <div className="h-full overflow-y-auto pb-16 lg:pb-0 bg-gray-50">
      {/* Desktop/Tablet Layout */}
      <div className="hidden md:block h-full p-6">
        <div className="h-full max-w-6xl mx-auto grid grid-rows-[auto_1fr] gap-6">
          {/* Tabs for Day/Week/Year */}
          <div className="flex rounded-xl overflow-hidden bg-white shadow-md w-full max-w-md mx-auto">
            <motion.button 
              className={`flex-1 py-3 px-4 text-lg font-medium ${activeTab === 'day' ? 'bg-primary text-white' : 'bg-white text-gray-700'}`}
              onClick={() => handleTabChange('day')}
              whileHover={{ backgroundColor: activeTab === 'day' ? '#3B7A96' : '#f8f8f8' }}
              whileTap={{ scale: 0.97 }}
            >
              Day
            </motion.button>
            <motion.button 
              className={`flex-1 py-3 px-4 text-lg font-medium ${activeTab === 'week' ? 'bg-primary text-white' : 'bg-white text-gray-700'}`}
              onClick={() => handleTabChange('week')}
              whileHover={{ backgroundColor: activeTab === 'week' ? '#3B7A96' : '#f8f8f8' }}
              whileTap={{ scale: 0.97 }}
            >
              Week
            </motion.button>
            <motion.button 
              className={`flex-1 py-3 px-4 text-lg font-medium ${activeTab === 'year' ? 'bg-primary text-white' : 'bg-white text-gray-700'}`}
              onClick={() => handleTabChange('year')}
              whileHover={{ backgroundColor: activeTab === 'year' ? '#3B7A96' : '#f8f8f8' }}
              whileTap={{ scale: 0.97 }}
            >
              Year
            </motion.button>
          </div>
          
          <div className="grid grid-cols-12 gap-6 h-full">
            {/* Left Column - Chart */}
            <div className="col-span-8 bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-6">
                <FaChartLine className="text-primary text-3xl mr-3" />
                <div className="text-xl font-bold text-gray-700">Visitor History</div>
              </div>
              <div className="h-[calc(100%-4rem)]">
                <LineChart data={historicalData} timeframe={activeTab} />
              </div>
            </div>
            
            {/* Right Column - Time and Visitor Count */}
            <div className="col-span-4 flex flex-col gap-6">
              <div className="bg-white p-6 rounded-xl shadow-md flex-grow">
                <TimeDisplay />
              </div>
              
              <div className="bg-primary text-white p-6 rounded-xl shadow-md flex-grow flex flex-col justify-center">
                <div className="flex justify-center mb-6">
                  <FaUsers className="text-white text-5xl" />
                </div>
                <h2 className="text-2xl text-center mb-4 font-bold">Current Count</h2>
                <DigitCounter 
                  digits={visitorCount} 
                  title="" 
                  className="flex justify-center"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Layout */}
      <div className="md:hidden p-4">
        {/* Tabs for Day/Week/Year */}
        <div className="flex rounded-lg overflow-hidden mb-5 bg-white shadow-md">
          <motion.button 
            className={`flex-1 py-3 px-4 ${activeTab === 'day' ? 'bg-primary text-white' : 'bg-white text-gray-700'}`}
            onClick={() => handleTabChange('day')}
            whileHover={{ backgroundColor: activeTab === 'day' ? '#3B7A96' : '#f8f8f8' }}
            whileTap={{ scale: 0.97 }}
          >
            Day
          </motion.button>
          <motion.button 
            className={`flex-1 py-3 px-4 ${activeTab === 'week' ? 'bg-primary text-white' : 'bg-white text-gray-700'}`}
            onClick={() => handleTabChange('week')}
            whileHover={{ backgroundColor: activeTab === 'week' ? '#3B7A96' : '#f8f8f8' }}
            whileTap={{ scale: 0.97 }}
          >
            Week
          </motion.button>
          <motion.button 
            className={`flex-1 py-3 px-4 ${activeTab === 'year' ? 'bg-primary text-white' : 'bg-white text-gray-700'}`}
            onClick={() => handleTabChange('year')}
            whileHover={{ backgroundColor: activeTab === 'year' ? '#3B7A96' : '#f8f8f8' }}
            whileTap={{ scale: 0.97 }}
          >
            Year
          </motion.button>
        </div>
        
        {/* Visitor Count Chart */}
        <div className="bg-white p-5 rounded-lg shadow-md mb-5">
          <div className="flex items-center mb-3">
            <FaChartLine className="text-primary text-2xl mr-2" />
            <div className="font-semibold text-gray-700">Count</div>
          </div>
          <LineChart data={historicalData} timeframe={activeTab} />
        </div>
        
        {/* Time Display */}
        <div className="mb-5">
          <TimeDisplay />
        </div>
        
        {/* Current Visitor Count */}
        <div className="bg-primary text-white p-5 rounded-lg shadow-md">
          <div className="flex justify-center mb-3">
            <FaUsers className="text-white text-4xl" />
          </div>
          <h2 className="text-xl text-center mb-3">Visitor's Count</h2>
          <DigitCounter 
            digits={visitorCount} 
            title="" 
            className="flex justify-center"
          />
        </div>
      </div>
    </div>
  );
};

export default HistoryPage;
