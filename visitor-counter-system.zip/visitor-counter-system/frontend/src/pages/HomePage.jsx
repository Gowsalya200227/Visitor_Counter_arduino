import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DigitCounter from '../components/DigitCounter';
import ToggleSwitch from '../components/ToggleSwitch';
import { getCurrentCount, getMaxLimit, setMaxLimit, controlAlarm, controlLight } from '../api/counterApi';
import { FaBell, FaLightbulb, FaUsers, FaCalendarAlt } from 'react-icons/fa';

const HomePage = () => {
  const [currentDate, setCurrentDate] = useState('');
  const [visitorCount, setVisitorCount] = useState(0);
  const [maxLimit, setMaxLimitValue] = useState(0);
  const [isAlarmOn, setIsAlarmOn] = useState(false);
  const [isLightOn, setIsLightOn] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set current date
    const date = new Date();
    setCurrentDate(date.toLocaleDateString('en-US', { 
      month: 'long', 
      day: '2-digit', 
      year: 'numeric' 
    }));

    // Load initial data
    fetchData();

    // Set up polling for real-time updates
    const interval = setInterval(fetchData, 3000);
    
    return () => clearInterval(interval);
  }, []);

  // Track whether switches have been manually toggled
  const [manualLightControl, setManualLightControl] = useState(false);
  const [manualAlarmControl, setManualAlarmControl] = useState(false);

  const fetchData = async () => {
    try {
      const [countResponse, maxLimitResponse] = await Promise.all([
        getCurrentCount(),
        getMaxLimit()
      ]);
      
      setVisitorCount(countResponse.count);
      setMaxLimitValue(maxLimitResponse.maxLimit);
      
      // Only update switch states from server if not manually controlled
      if (!manualLightControl) {
        setIsLightOn(countResponse.lightStatus);
      }
      
      if (!manualAlarmControl) {
        setIsAlarmOn(countResponse.alarmStatus);
      }
      
      // Auto-toggle light based on visitor count ONLY if not manually controlled
      if (!manualLightControl) {
        if (countResponse.count > 0 && !countResponse.lightStatus) {
          await handleLightToggle(true, false); // false = not manual toggle
        } else if (countResponse.count === 0 && countResponse.lightStatus) {
          await handleLightToggle(false, false); // false = not manual toggle
        }
      }
      
      // Auto-toggle alarm based on max limit ONLY if not manually controlled
      if (!manualAlarmControl) {
        if (countResponse.count >= maxLimitResponse.maxLimit && maxLimitResponse.maxLimit > 0 && !countResponse.alarmStatus) {
          await handleAlarmToggle(true, false); // false = not manual toggle
        } else if ((countResponse.count < maxLimitResponse.maxLimit || maxLimitResponse.maxLimit === 0) && countResponse.alarmStatus) {
          await handleAlarmToggle(false, false); // false = not manual toggle
        }
      }
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  const handleDigitChange = (index, value, isMaxLimit) => {
    if (isMaxLimit) {
      const digits = maxLimit.toString().padStart(4, '0').split('');
      digits[index] = value;
      const newMaxLimit = parseInt(digits.join(''));
      setMaxLimitValue(newMaxLimit);
      setMaxLimit(newMaxLimit);
    }
  };

  const handleAlarmToggle = async (status, isManual = true) => {
    try {
      await controlAlarm(status);
      setIsAlarmOn(status);
      
      // Mark as manually controlled if this was a manual toggle
      if (isManual) {
        setManualAlarmControl(true);
        // Show a message or feedback that control is now manual
        console.log('Alarm manually set to:', status ? 'ON' : 'OFF');
      }
    } catch (error) {
      console.error('Error toggling alarm:', error);
    }
  };

  const handleLightToggle = async (status, isManual = true) => {
    try {
      await controlLight(status);
      setIsLightOn(status);
      
      // Mark as manually controlled if this was a manual toggle
      if (isManual) {
        setManualLightControl(true);
        // Show a message or feedback that control is now manual
        console.log('Light manually set to:', status ? 'ON' : 'OFF');
      }
    } catch (error) {
      console.error('Error toggling light:', error);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }

  return (
    <div className="h-full bg-gray-50">
      {/* Desktop/Tablet Layout */}
      <div className="hidden md:block h-full p-6">
        <div className="h-full max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div className="text-xl text-gray-600 font-medium">{currentDate}</div>
            <motion.button 
              className="bg-transparent"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaCalendarAlt className="h-6 w-6 text-primary" />
            </motion.button>
          </div>
          
          <div className="grid grid-cols-12 gap-6 h-[calc(100%-4rem)]">
            {/* Left Column - Visitor Count */}
            <div className="col-span-5 flex flex-col">
              <div className="bg-primary text-white p-8 rounded-xl shadow-md mb-6 flex-grow flex flex-col justify-center items-center">
                <motion.div 
                  className="flex justify-center mb-6"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                >
                  <FaUsers className="text-white text-6xl" />
                </motion.div>
                <h2 className="text-2xl text-center mb-6 font-bold">Visitor's Count</h2>
                <DigitCounter 
                  digits={visitorCount} 
                  title="" 
                  className="flex justify-center"
                />
              </div>
            </div>
            
            {/* Right Column - Controls and Max Limit */}
            <div className="col-span-7 grid grid-rows-2 gap-6">
              {/* Control Toggles */}
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-md flex flex-col justify-center">
                  <div className="flex flex-col items-center">
                    <FaBell className="text-primary text-4xl mb-4" />
                    <div className="text-gray-700 mb-4 text-lg font-medium">Alarm</div>
                    <ToggleSwitch 
                      isOn={isAlarmOn} 
                      handleToggle={() => handleAlarmToggle(!isAlarmOn)} 
                      label="" 
                    />
                  </div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-md flex flex-col justify-center">
                  <div className="flex flex-col items-center">
                    <FaLightbulb className="text-primary text-4xl mb-4" />
                    <div className="text-gray-700 mb-4 text-lg font-medium">Light</div>
                    <ToggleSwitch 
                      isOn={isLightOn} 
                      handleToggle={() => handleLightToggle(!isLightOn)} 
                      label="" 
                    />
                  </div>
                </div>
              </div>
              
              {/* Max Limit */}
              <div className="bg-white p-8 rounded-xl shadow-md flex flex-col justify-center">
                <h2 className="text-2xl text-center mb-6 text-gray-700 font-bold">Maximum Visitor Limit</h2>
                <div className="bg-gray-100 p-6 rounded-lg">
                  <DigitCounter 
                    digits={maxLimit} 
                    title="" 
                    isEditable={true}
                    handleDigitChange={(index, value) => handleDigitChange(index, value, true)}
                    className="flex justify-center"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Layout - Optimized to prevent scrolling */}
      <div className="md:hidden h-full flex flex-col">
        <div className="flex justify-between items-center px-4 pt-3 pb-2">
          <div className="text-lg text-gray-600">{currentDate}</div>
          <motion.button 
            className="bg-transparent"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaCalendarAlt className="h-5 w-5 text-gray-500" />
          </motion.button>
        </div>
        
        {/* Visitor Count - Reduced padding */}
        <div className="bg-primary text-white p-4 rounded-lg shadow-md mx-3 mb-3 flex-shrink-0">
          <div className="flex justify-center mb-2">
            <FaUsers className="text-white text-3xl" />
          </div>
          <h2 className="text-xl text-center mb-2">Visitor's Count</h2>
          <DigitCounter 
            digits={visitorCount} 
            title="" 
            className="flex justify-center"
          />
        </div>
        
        {/* Control Toggles - Using flex layout to distribute space better */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 px-3 mb-3 flex-shrink-0">
          <div className="bg-white p-3 rounded-lg shadow-md">
            <div className="flex flex-col items-center">
              <FaBell className="text-primary text-3xl mb-1" />
              <div className="text-gray-700 mb-1">Alarm</div>
              <ToggleSwitch 
                isOn={isAlarmOn} 
                handleToggle={() => handleAlarmToggle(!isAlarmOn)} 
                label="" 
              />
            </div>
          </div>
          <div className="bg-white p-3 rounded-lg shadow-md">
            <div className="flex flex-col items-center">
              <FaLightbulb className="text-primary text-3xl mb-1" />
              <div className="text-gray-700 mb-1">Light</div>
              <ToggleSwitch 
                isOn={isLightOn} 
                handleToggle={() => handleLightToggle(!isLightOn)} 
                label="" 
              />
            </div>
          </div>
        </div>
        
        {/* Max Limit - Optimized for space */}
        <div className="bg-white rounded-lg shadow-md mx-3 flex-1 flex flex-col">
          <h2 className="text-lg text-center py-2 text-gray-700 font-medium">Max Limit</h2>
          <div className="bg-gray-100 p-2 rounded-b-lg flex-1 flex flex-col justify-center">
            <DigitCounter 
              digits={maxLimit} 
              title="" 
              isEditable={true}
              handleDigitChange={(index, value) => handleDigitChange(index, value, true)}
              className="flex justify-center"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;