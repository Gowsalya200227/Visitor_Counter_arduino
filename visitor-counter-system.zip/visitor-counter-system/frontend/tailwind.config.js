/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#4B8BA7',
        'primary-dark': '#3B7A96',
        'primary-light': '#6CA5BC',
        secondary: '#E5E7EB',
        background: '#F5F7FA',
      },
    },
  },
  plugins: [],
}