# Visitor Counter System - Node.js Backend

This is the Node.js/Express backend for the Visitor Counter System with MongoDB integration.

## Features

- Real-time visitor count tracking
- MongoDB persistence for visitor data
- Socket.io for real-time updates
- Alarm and light control based on visitor count
- Historical data visualization (day, week, year)
- Embedded device connection using Serial communication
- Built-in simulator mode for testing without physical hardware

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (local or Atlas connection)
- npm or yarn

## Installation

1. Clone the repository
2. Install dependencies:
```
npm install
```
3. Create a `.env` file in the root directory with the following variables:
```
PORT=8082
MONGO_URI=mongodb://localhost:27017/visitor-counter
NODE_ENV=development
SIMULATOR_MODE=true  # Set to false to use real hardware
```

## Running the Application

Development mode:
```
npm run dev
```

Production mode:
```
npm start
```

## API Endpoints

### Counter API

- `GET /api/counter/current` - Get current visitor count and status
- `GET /api/counter/maxlimit` - Get max visitor limit
- `POST /api/counter/maxlimit` - Set max visitor limit
- `POST /api/counter/alarm` - Control alarm status
- `POST /api/counter/light` - Control light status
- `GET /api/counter/history/:timeframe` - Get historical data (day/week/year)
- `POST /api/counter/update` - Manual update endpoint (for testing)

### Embedded Device API

- `GET /api/embedded/status` - Check connection status
- `POST /api/embedded/connect` - Connect to the embedded device
- `POST /api/embedded/disconnect` - Disconnect from the embedded device
- `POST /api/embedded/command` - Send a command to the embedded device

### Debug API

- `GET /api/debug/ping` - Ping the server
- `GET /api/debug/info` - Get system information

## Serial Communication Protocol

The system uses the following protocol for embedded device communication:

1. Receiving visitor count:
   ```
   COUNT:42
   ```

2. Sending commands:
   - Turn on light: `LIGHT:ON`
   - Turn off light: `LIGHT:OFF`
   - Turn on alarm: `ALARM:ON`
   - Turn off alarm: `ALARM:OFF`
