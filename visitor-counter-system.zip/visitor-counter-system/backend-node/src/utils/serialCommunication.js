const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

class SerialCommunicationService {
    constructor() {
        this.port = null;
        this.parser = null;
        this.connected = false;
        this.dataCallback = null;
        this.simulatorMode = process.env.SIMULATOR_MODE === 'true';
        this.visitorCount = 0;
        this.lightStatus = false;
        this.alarmStatus = false;
        
        // If in simulator mode, start the simulator
        if (this.simulatorMode) {
            this.startSimulator();
        }
    }

    isConnected() {
        return this.connected || this.simulatorMode;
    }

    connect(portName, baudRate) {
        // If simulator mode is on, just set connected to true
        if (this.simulatorMode) {
            this.connected = true;
            return true;
        }

        try {
            if (this.isConnected()) {
                this.disconnect();
            }

            this.port = new SerialPort({
                path: portName,
                baudRate: parseInt(baudRate, 10),
                autoOpen: false
            });

            this.parser = this.port.pipe(new ReadlineParser({ delimiter: '\n' }));

            // Set up event handlers
            this.port.on('open', () => {
                console.log(`Connected to serial port: ${portName}`);
                this.connected = true;
            });

            this.port.on('error', (err) => {
                console.error('Serial port error:', err.message);
                this.connected = false;
            });

            this.port.on('close', () => {
                console.log('Serial port closed');
                this.connected = false;
            });

            // Process incoming data
            this.parser.on('data', (data) => {
                this.processReceivedData(data);
            });

            // Open the port
            this.port.open((err) => {
                if (err) {
                    console.error('Error opening port:', err.message);
                    return false;
                }
            });

            return true;
        } catch (error) {
            console.error('Failed to connect to serial port:', error);
            return false;
        }
    }

    disconnect() {
        // If simulator mode is on, just set connected to false
        if (this.simulatorMode) {
            this.connected = false;
            return;
        }

        if (this.port && this.port.isOpen) {
            this.port.close();
        }
        this.connected = false;
    }

    sendCommand(command) {
        // If simulator mode is on, handle the command in the simulator
        if (this.simulatorMode) {
            this.processSimulatorCommand(command);
            return true;
        }

        if (!this.isConnected()) {
            console.error('Cannot send command - not connected to serial port');
            return false;
        }

        try {
            this.port.write(`${command}\n`);
            console.log(`Sent command: ${command}`);
            return true;
        } catch (error) {
            console.error('Failed to send command:', error);
            return false;
        }
    }

    setDataCallback(callback) {
        this.dataCallback = callback;
    }

    processReceivedData(data) {
        console.log(`Received data: ${data}`);
        if (this.dataCallback) {
            this.dataCallback(data);
        }
    }

    // Simulator methods
    startSimulator() {
        console.log('Starting device simulator');
        
        // Randomly adjust the count every 5 seconds
        setInterval(() => {
            if (Math.random() < 0.3) { // 30% chance to change
                const change = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
                this.visitorCount = Math.max(0, this.visitorCount + change);
                
                // Send the count update
                if (this.dataCallback) {
                    this.dataCallback(`COUNT:${this.visitorCount}`);
                }
                
                console.log(`Simulated visitor count: ${this.visitorCount}`);
            }
        }, 5000);
    }

    processSimulatorCommand(command) {
        console.log(`Simulator received command: ${command}`);
        
        if (command === 'LIGHT:ON') {
            this.lightStatus = true;
            console.log('Simulator: Light turned ON');
        } else if (command === 'LIGHT:OFF') {
            this.lightStatus = false;
            console.log('Simulator: Light turned OFF');
        } else if (command === 'ALARM:ON') {
            this.alarmStatus = true;
            console.log('Simulator: Alarm turned ON');
        } else if (command === 'ALARM:OFF') {
            this.alarmStatus = false;
            console.log('Simulator: Alarm turned OFF');
        }
    }
}

module.exports = new SerialCommunicationService();
