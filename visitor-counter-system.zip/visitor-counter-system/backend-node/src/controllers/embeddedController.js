const serialService = require('../utils/serialCommunication');

exports.getConnectionStatus = (req, res) => {
    try {
        res.status(200).json({
            connected: serialService.isConnected()
        });
    } catch (error) {
        console.error('Error checking connection status:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.connect = (req, res) => {
    try {
        const { port, baudRate } = req.body;
        
        if (!port || !baudRate) {
            return res.status(400).json({
                error: 'Both port and baudRate are required',
                connected: false
            });
        }
        
        const success = serialService.connect(port, baudRate);
        
        res.status(200).json({
            connected: success,
            port,
            baudRate,
            error: success ? undefined : 'Failed to connect to the specified port'
        });
    } catch (error) {
        console.error('Error connecting to embedded device:', error);
        res.status(500).json({ 
            error: error.message,
            connected: false
        });
    }
};

exports.disconnect = (req, res) => {
    try {
        serialService.disconnect();
        
        res.status(200).json({
            connected: false,
            success: true
        });
    } catch (error) {
        console.error('Error disconnecting from embedded device:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.sendCommand = (req, res) => {
    try {
        const { command } = req.body;
        
        if (!command || command.trim() === '') {
            return res.status(400).json({
                error: 'Command is required',
                success: false
            });
        }
        
        if (!serialService.isConnected()) {
            return res.status(400).json({
                error: 'Not connected to any serial device',
                success: false
            });
        }
        
        const success = serialService.sendCommand(command);
        
        res.status(200).json({
            success,
            command,
            error: success ? undefined : 'Failed to send command'
        });
    } catch (error) {
        console.error('Error sending command to embedded device:', error);
        res.status(500).json({ 
            error: error.message,
            success: false
        });
    }
};
