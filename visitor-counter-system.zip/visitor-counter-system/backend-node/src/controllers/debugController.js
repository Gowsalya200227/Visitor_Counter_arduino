const os = require('os');

exports.ping = (req, res) => {
    res.status(200).json({
        status: 'ok',
        message: 'Ping successful'
    });
};

exports.getSystemInfo = (req, res) => {
    res.status(200).json({
        nodeVersion: process.version,
        osName: os.type(),
        osVersion: os.release(),
        platform: os.platform(),
        architecture: os.arch(),
        availableProcessors: os.cpus().length,
        freeMemory: os.freemem(),
        totalMemory: os.totalmem(),
        uptime: os.uptime()
    });
};
