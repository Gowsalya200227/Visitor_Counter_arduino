const serialService = require('../utils/serialCommunication');

// In-memory data store
const visitorRecords = [];
const maxLimitHistory = [{ maxLimit: 10, createdAt: new Date() }];

// Current visitor state
let currentCount = 0;
let lightStatus = false;
let alarmStatus = false;

// Initialize
const initializeState = () => {
    try {
        // Get the last record if available
        if (visitorRecords.length > 0) {
            const lastRecord = visitorRecords[visitorRecords.length - 1];
            currentCount = lastRecord.count;
            lightStatus = lastRecord.lightStatus;
            alarmStatus = lastRecord.alarmStatus;
        }

        // Register as callback for serial data
        serialService.setDataCallback(processEmbeddedData);
        
        console.log('Counter state initialized:', { currentCount, lightStatus, alarmStatus });
    } catch (error) {
        console.error('Error initializing counter state:', error);
    }
};

// Process data received from embedded device
const processEmbeddedData = (data) => {
    // Parse the count data
    const countMatch = data.match(/COUNT:(\d+)/);
    if (countMatch) {
        const newCount = parseInt(countMatch[1], 10);
        updateVisitorCount(newCount);
    }
};

// Call initialize function
initializeState();

// Controller methods
exports.getCurrentCount = (req, res) => {
    try {
        const result = {
            count: currentCount,
            alarmStatus,
            lightStatus,
            timestamp: new Date()
        };
        
        res.status(200).json(result);
    } catch (error) {
        console.error('Error getting current count:', error);
        res.status(500).json({ error: error.message, status: 'error' });
    }
};

exports.getMaxLimit = (req, res) => {
    try {
        // Get the most recent max limit from the in-memory store
        const maxLimit = maxLimitHistory[maxLimitHistory.length - 1];
        
        res.status(200).json({
            maxLimit: maxLimit ? maxLimit.maxLimit : 0
        });
    } catch (error) {
        console.error('Error getting max limit:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.setMaxLimit = (req, res) => {
    try {
        const { maxLimit } = req.body;
        
        if (maxLimit === undefined) {
            return res.status(400).json({ error: 'maxLimit is required' });
        }
        
        // Create a new max limit record
        const newMaxLimit = { maxLimit, createdAt: new Date() };
        maxLimitHistory.push(newMaxLimit);
        
        // After updating max limit, check if we need to activate/deactivate alarm
        checkAlarmAgainstMaxLimit();
        
        res.status(200).json({
            maxLimit: newMaxLimit.maxLimit,
            success: true
        });
    } catch (error) {
        console.error('Error setting max limit:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.setAlarmStatus = (req, res) => {
    try {
        const { status } = req.body;
        
        if (status === undefined) {
            return res.status(400).json({ error: 'status is required' });
        }
        
        const result = setAlarm(status);
        
        res.status(200).json({
            alarmStatus: status,
            success: result
        });
    } catch (error) {
        console.error('Error setting alarm status:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.setLightStatus = (req, res) => {
    try {
        const { status } = req.body;
        
        if (status === undefined) {
            return res.status(400).json({ error: 'status is required' });
        }
        
        const result = setLight(status);
        
        res.status(200).json({
            lightStatus: status,
            success: result
        });
    } catch (error) {
        console.error('Error setting light status:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.getHistoricalData = (req, res) => {
    try {
        const { timeframe } = req.params;
        
        if (!['day', 'week', 'year'].includes(timeframe.toLowerCase())) {
            return res.status(400).json({
                error: 'Invalid timeframe. Must be "day", "week", or "year"'
            });
        }
        
        const data = getTimeframeData(timeframe.toLowerCase());
        
        res.status(200).json({
            timeframe,
            data
        });
    } catch (error) {
        console.error('Error getting historical data:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.updateCount = (req, res) => {
    try {
        const { count } = req.body;
        
        if (count === undefined) {
            return res.status(400).json({ error: 'count is required' });
        }
        
        updateVisitorCount(count);
        
        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Error updating count:', error);
        res.status(500).json({ error: error.message });
    }
};

// Helper functions
const updateVisitorCount = (newCount) => {
    if (currentCount !== newCount) {
        console.log(`Visitor count changed: ${currentCount} -> ${newCount}`);
        currentCount = newCount;
        
        // Auto-toggle light based on count
        if (newCount > 0 && !lightStatus) {
            setLight(true);
        } else if (newCount === 0 && lightStatus) {
            setLight(false);
        }
        
        // Check max limit and handle alarm
        checkAlarmAgainstMaxLimit();
        
        // Save the record
        const record = {
            count: newCount,
            alarmStatus,
            lightStatus,
            timestamp: new Date()
        };
        visitorRecords.push(record);
        
        // Keep records size manageable
        if (visitorRecords.length > 1000) {
            visitorRecords.shift(); // Remove oldest record
        }
        
        // Send real-time update via Socket.io
        if (global.io) {
            global.io.emit('countUpdate', {
                count: newCount,
                alarmStatus,
                lightStatus,
                timestamp: new Date()
            });
        }
    }
};

const setAlarm = (status) => {
    if (alarmStatus !== status) {
        alarmStatus = status;
        
        // Send command to embedded device
        const command = status ? 'ALARM:ON' : 'ALARM:OFF';
        const sent = serialService.sendCommand(command);
        
        console.log(`Alarm status set to ${status}, command sent: ${sent}`);
        return sent;
    }
    return true; // No change needed
};

const setLight = (status) => {
    if (lightStatus !== status) {
        lightStatus = status;
        
        // Send command to embedded device
        const command = status ? 'LIGHT:ON' : 'LIGHT:OFF';
        const sent = serialService.sendCommand(command);
        
        console.log(`Light status set to ${status}, command sent: ${sent}`);
        return sent;
    }
    return true; // No change needed
};

const checkAlarmAgainstMaxLimit = () => {
    // Get the most recent max limit
    const maxLimit = maxLimitHistory[maxLimitHistory.length - 1];
    
    if (maxLimit && maxLimit.maxLimit > 0) {
        if (currentCount >= maxLimit.maxLimit && !alarmStatus) {
            setAlarm(true);
        } else if (currentCount < maxLimit.maxLimit && alarmStatus) {
            setAlarm(false);
        }
    }
};

const getTimeframeData = (timeframe) => {
    const now = new Date();
    let startDate;
    
    switch (timeframe) {
        case 'day':
            // Last 24 hours data, hourly points
            startDate = new Date(now);
            startDate.setHours(now.getHours() - 24);
            return getHourlyData(startDate, now);
            
        case 'week':
            // Last 7 days data, daily points
            startDate = new Date(now);
            startDate.setDate(now.getDate() - 7);
            return getDailyData(startDate, now);
            
        case 'year':
            // Last 12 months data, monthly points
            startDate = new Date(now);
            startDate.setMonth(now.getMonth() - 12);
            return getMonthlyData(startDate, now);
            
        default:
            throw new Error(`Invalid timeframe: ${timeframe}`);
    }
};

const getHourlyData = (start, end) => {
    const hourlyData = [];
    
    // Filter records between start and end
    const records = visitorRecords.filter(record => 
        record.timestamp >= start && record.timestamp <= end);
    
    // Group by hour
    const hourlyGrouped = {};
    
    records.forEach(record => {
        const hour = new Date(record.timestamp).getHours();
        if (!hourlyGrouped[hour]) {
            hourlyGrouped[hour] = [];
        }
        hourlyGrouped[hour].push(record);
    });
    
    // For each hour in the past 24 hours
    for (let i = 0; i < 24; i++) {
        const hour = new Date(end);
        hour.setHours(end.getHours() - 24 + i);
        const hourKey = hour.getHours();
        
        const hourRecords = hourlyGrouped[hourKey] || [];
        
        // Average count or 0 if no records
        const avgCount = hourRecords.length === 0 ? 0 : 
            Math.round(hourRecords.reduce((sum, record) => sum + record.count, 0) / hourRecords.length);
        
        hourlyData.push(avgCount);
    }
    
    return hourlyData;
};

const getDailyData = (start, end) => {
    const dailyData = [];
    
    // For each day in the past week
    for (let i = 0; i < 7; i++) {
        const day = new Date(end);
        day.setDate(end.getDate() - 7 + i);
        day.setHours(0, 0, 0, 0);
        
        const nextDay = new Date(day);
        nextDay.setDate(day.getDate() + 1);
        
        // Filter records for this day
        const dayRecords = visitorRecords.filter(record => 
            record.timestamp >= day && record.timestamp < nextDay);
            
        // Get max count for the day or 0 if no records
        const maxCount = dayRecords.length === 0 ? 0 :
            Math.max(...dayRecords.map(record => record.count));
        
        dailyData.push(maxCount);
    }
    
    return dailyData;
};

const getMonthlyData = (start, end) => {
    const monthlyData = [];
    
    // For each month in the past year
    for (let i = 0; i < 12; i++) {
        const month = new Date(end);
        month.setMonth(end.getMonth() - 12 + i);
        month.setDate(1);
        month.setHours(0, 0, 0, 0);
        
        const nextMonth = new Date(month);
        nextMonth.setMonth(month.getMonth() + 1);
        
        // Filter records for this month
        const monthRecords = visitorRecords.filter(record => 
            record.timestamp >= month && record.timestamp < nextMonth);
            
        // Get max count for the month or 0 if no records
        const maxCount = monthRecords.length === 0 ? 0 :
            Math.max(...monthRecords.map(record => record.count));
        
        monthlyData.push(maxCount);
    }
    
    return monthlyData;
};

// Periodically save the current count (in a real app, this would save to DB)
setInterval(() => {
    const record = {
        count: currentCount,
        alarmStatus,
        lightStatus,
        timestamp: new Date()
    };
    visitorRecords.push(record);
    
    // Keep records size manageable
    if (visitorRecords.length > 1000) {
        visitorRecords.shift(); // Remove oldest record
    }
    
    console.log(`Periodic record saved: count=${currentCount}`);
}, 300000); // Every 5 minutes

// Generate some initial historical data
const generateInitialData = () => {
    const now = new Date();
    
    // Generate data for the past week
    for (let i = 7; i >= 0; i--) {
        const timestamp = new Date(now);
        timestamp.setDate(now.getDate() - i);
        
        // Random count between 0 and 15
        const count = Math.floor(Math.random() * 16);
        
        visitorRecords.push({
            count,
            alarmStatus: count > 10,
            lightStatus: count > 0,
            timestamp
        });
    }
    
    console.log(`Generated ${visitorRecords.length} initial records`);
};

// Generate initial data
generateInitialData();
