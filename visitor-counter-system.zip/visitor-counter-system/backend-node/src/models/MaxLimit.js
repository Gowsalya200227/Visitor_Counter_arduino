const mongoose = require('mongoose');

const maxLimitSchema = new mongoose.Schema({
    maxLimit: {
        type: Number,
        required: true,
        default: 10
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('MaxLimit', maxLimitSchema);
