const mongoose = require('mongoose');

const visitorCountSchema = new mongoose.Schema({
    count: {
        type: Number,
        required: true,
        default: 0
    },
    timestamp: {
        type: Date,
        default: Date.now
    },
    alarmStatus: {
        type: Boolean,
        default: false
    },
    lightStatus: {
        type: Boolean,
        default: false
    }
});

module.exports = mongoose.model('VisitorCount', visitorCountSchema);
