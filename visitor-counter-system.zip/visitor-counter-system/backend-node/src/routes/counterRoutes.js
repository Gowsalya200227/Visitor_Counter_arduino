const express = require('express');
const router = express.Router();
const counterController = require('../controllers/counterController');

// Test endpoint
router.get('/test', (req, res) => {
    res.status(200).json({
        status: 'ok',
        message: 'Counter API is working'
    });
});

// Get current visitor count and status
router.get('/current', counterController.getCurrentCount);

// Get/Set max visitor limit
router.get('/maxlimit', counterController.getMaxLimit);
router.post('/maxlimit', counterController.setMaxLimit);

// Control alarm and light status
router.post('/alarm', counterController.setAlarmStatus);
router.post('/light', counterController.setLightStatus);

// Get historical data
router.get('/history/:timeframe', counterController.getHistoricalData);

// Manual update endpoint (for testing)
router.post('/update', counterController.updateCount);

module.exports = router;
