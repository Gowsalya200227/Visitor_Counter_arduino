const express = require('express');
const router = express.Router();
const embeddedController = require('../controllers/embeddedController');

// Get connection status
router.get('/status', embeddedController.getConnectionStatus);

// Connect to embedded device
router.post('/connect', embeddedController.connect);

// Disconnect from embedded device
router.post('/disconnect', embeddedController.disconnect);

// Send command to embedded device
router.post('/command', embeddedController.sendCommand);

module.exports = router;
