const express = require('express');
const router = express.Router();
const debugController = require('../controllers/debugController');

// Ping endpoint
router.get('/ping', debugController.ping);

// System information endpoint
router.get('/info', debugController.getSystemInfo);

module.exports = router;
