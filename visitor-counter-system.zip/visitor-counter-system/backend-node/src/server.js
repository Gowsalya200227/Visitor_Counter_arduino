const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
require('dotenv').config();

// Route imports
const counterRoutes = require('./routes/counterRoutes');
const embeddedRoutes = require('./routes/embeddedRoutes');
const debugRoutes = require('./routes/debugRoutes');

// Middleware
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Make io available globally
global.io = io;

// Port configuration
const PORT = process.env.PORT || 8082;

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Add io to request object
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Routes
app.use('/api/counter', counterRoutes);
app.use('/api/embedded', embeddedRoutes);
app.use('/api/debug', debugRoutes);

// Socket.io connection
io.on('connection', (socket) => {
  console.log('New client connected');
  
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

// Start server
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Server running in ${process.env.SIMULATOR_MODE === 'true' ? 'SIMULATOR' : 'REAL DEVICE'} mode`);
});
