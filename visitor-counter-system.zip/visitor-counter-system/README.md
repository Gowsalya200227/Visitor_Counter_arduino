# Visitor Counter System

A full-stack MERN application to connect with an embedded visitor counter device. The system features real-time visitor tracking, alarm and light control based on visitor count, and historical data visualization.

## Project Structure

- **Frontend**: React + Vite + Tailwind CSS
- **Backend**: Node.js + Express + In-memory data storage (MongoDB-ready)
- **Integration**: Serial communication with embedded C-based visitor counter
- **Real-time**: Socket.io for real-time updates

## Features

- Real-time visitor count display with beautiful UI
- Automatic light control when visitors are present
- Configurable maximum visitor limit with alarm
- Historical data visualization (day, week, year)
- Embedded system connection management
- Responsive design for mobile, tablet and desktop
- Simulator mode for testing without physical hardware

## Frontend Setup

1. Navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```
   
## Backend Setup

1. Navigate to the backend directory:
   ```
   cd backend-node
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Create a `.env` file in the root directory with the following variables:
   ```
   PORT=8082
   NODE_ENV=development
   SIMULATOR_MODE=true  # Set to false to use real hardware
   ```

4. Start the development server:
   ```
   npm run dev
   ```

4. The frontend will be available at: http://localhost:5173

## API Endpoints

### Counter API

- `GET /api/counter/current` - Get current visitor count and status
- `GET /api/counter/maxlimit` - Get max visitor limit
- `POST /api/counter/maxlimit` - Set max visitor limit
- `POST /api/counter/alarm` - Control alarm status
- `POST /api/counter/light` - Control light status
- `GET /api/counter/history/:timeframe` - Get historical data (day/week/year)

### Embedded Device API

- `GET /api/embedded/status` - Check connection status
- `POST /api/embedded/connect` - Connect to the embedded device
- `POST /api/embedded/disconnect` - Disconnect from the embedded device
- `POST /api/embedded/command` - Send a command to the embedded device

### Debug API

- `GET /api/debug/ping` - Ping the server
- `GET /api/debug/info` - Get system information

## Serial Communication Protocol

The system uses the following protocol for embedded device communication:

1. Receiving visitor count:
   ```
   COUNT:42
   ```

2. Sending commands:
   - Turn on light: `LIGHT:ON`
   - Turn off light: `LIGHT:OFF`
   - Turn on alarm: `ALARM:ON`
   - Turn off alarm: `ALARM:OFF`

## Running in Production

Both frontend and backend have appropriate build scripts for production deployment:

### Frontend
```
cd frontend
npm run build
```

### Backend
```
cd backend-node
npm start
```

## Backend Setup

1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Build the project:
   ```
   ./mvnw clean package
   ```
   
3. Run the Spring Boot application:
   ```
   ./mvnw spring-boot:run
   ```

4. The backend API will be available at: http://localhost:8080

## Connecting to Your Embedded Device

1. When you first launch the application, you'll see a connection screen.
2. Enter the serial port your C-based embedded device is connected to:
   - Linux/Mac: typically `/dev/ttyUSB0` or `/dev/ttyACM0`
   - Windows: typically `COM3` or similar
3. Select the appropriate baud rate (matches what your C program uses)
4. Click "Connect" to establish communication with your device

## API Endpoints

### Counter API

- `GET /api/counter/current` - Get current visitor count and status
- `GET /api/counter/maxlimit` - Get max visitor limit
- `POST /api/counter/maxlimit` - Set max visitor limit
- `POST /api/counter/alarm` - Control alarm status
- `POST /api/counter/light` - Control light status
- `GET /api/counter/history/{timeframe}` - Get historical data (day/week/year)

### Embedded Device API

- `GET /api/embedded/status` - Check connection status
- `POST /api/embedded/connect` - Connect to the embedded device
- `POST /api/embedded/disconnect` - Disconnect from the embedded device
- `POST /api/embedded/command` - Send a command to the embedded device

## Embedded System Protocol

The system expects your C-based embedded counter to communicate over serial with the following protocol:

1. Sending visitor count:
   ```
   COUNT:42
   ```

2. Receiving commands:
   - Turn on light: `LIGHT:ON`
   - Turn off light: `LIGHT:OFF`
   - Turn on alarm: `ALARM:ON`
   - Turn off alarm: `ALARM:OFF`

Make sure your embedded C code can parse these commands and send the COUNT data.

## Screenshots

The application UI matches the design shown in the provided mockups:
- Home page with current visitor count, light/alarm toggles, and max limit setting
- History page with data visualization and time period selection