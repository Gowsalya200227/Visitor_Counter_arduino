#include "mqtt.h"
#include "config.h"
#include <string.h>

static const char *TAG = "MQTT";
static esp_mqtt_client_handle_t client;

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, 
                             int32_t event_id, void *event_data) {
    esp_mqtt_event_handle_t event = event_data;
    
    switch ((esp_mqtt_event_id_t)event_id) {
        case MQTT_EVENT_BEFORE_CONNECT:
            ESP_LOGI(TAG, "Connecting to MQTT broker...");
            break;
            
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
            esp_mqtt_client_subscribe(client, MQTT_TOPIC_LED, 0);
            break;
            
        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED");
            break;
            
        case MQTT_EVENT_DATA:
            ESP_LOGI(TAG, "MQTT_EVENT_DATA");
            printf("TOPIC=%.*s\r\n", event->topic_len, event->topic);
            printf("DATA=%.*s\r\n", event->data_len, event->data);
            
            if (strncmp(event->topic, MQTT_TOPIC_LED, event->topic_len) == 0) {
                if (strncmp(event->data, "ON", event->data_len) == 0) {
                    gpio_set_level(LED_PIN, 1);
                    ESP_LOGI(TAG, "LED turned ON via MQTT");
                } else if (strncmp(event->data, "OFF", event->data_len) == 0) {
                    gpio_set_level(LED_PIN, 0);
                    ESP_LOGI(TAG, "LED turned OFF via MQTT");
                }
            }
            break;
            
        case MQTT_EVENT_ERROR:
            ESP_LOGE(TAG, "MQTT_EVENT_ERROR");
            break;
            
        default:
            ESP_LOGI(TAG, "Other MQTT event id:%d", event->event_id);
            break;
    }
}

void mqtt_app_start() {
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = CONFIG_MQTT_BROKER_URL,
        .broker.address.port = CONFIG_MQTT_BROKER_PORT,
        .credentials.client_id = CONFIG_MQTT_CLIENT_ID,
    };

    client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    esp_mqtt_client_start(client);
}

void mqtt_publish_count(int count) {
    char count_str[10];
    snprintf(count_str, sizeof(count_str), "%d", count);
    esp_mqtt_client_publish(client, MQTT_TOPIC_COUNT, count_str, 0, 0, 0);
}

void mqtt_publish_event(const char* topic) {
    esp_mqtt_client_publish(client, topic, "1", 0, 0, 0);
}