#include "visitor_counter.h"
#include "config.h"
#include "display.h"
#include "mqtt.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/task.h"

static const char *TAG = "VISITOR";
static int visitor_count = 0;

static unsigned long last_debounce_time = 0;
static bool entry_first = false;
static bool exit_first = false;
static bool entry_confirmed = false;
static bool exit_confirmed = false;

void visitor_counter_init() {
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << IR_SENSOR_ENTRY) | (1ULL << IR_SENSOR_EXIT),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io_conf);

    gpio_config_t led_conf = {
        .pin_bit_mask = (1ULL << LED_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&led_conf);
}

void visitor_counter_update() {
    int entry_state = gpio_get_level(IR_SENSOR_ENTRY);
    int exit_state = gpio_get_level(IR_SENSOR_EXIT);
    unsigned long current_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    // Process entry detection
    if (entry_state == 0 && !entry_first && (current_time - last_debounce_time > DEBOUNCE_DELAY)) {
        entry_first = true;
        last_debounce_time = current_time;
    }
    if (exit_state == 0 && entry_first && !entry_confirmed && (current_time - last_debounce_time > DEBOUNCE_DELAY)) {
        visitor_count++;
        ESP_LOGI(TAG, "Visitor Entered. Count: %d", visitor_count);
        update_display(visitor_count);
        
        mqtt_publish_count(visitor_count);
        mqtt_publish_event(MQTT_TOPIC_ENTRY);
        
        entry_confirmed = true;
        entry_first = false;
        last_debounce_time = current_time;
    }
    
    // Process exit detection
    if (exit_state == 0 && !exit_first && (current_time - last_debounce_time > DEBOUNCE_DELAY)) {
        exit_first = true;
        last_debounce_time = current_time;
    }
    if (entry_state == 0 && exit_first && !exit_confirmed && (current_time - last_debounce_time > DEBOUNCE_DELAY)) {
        visitor_count = visitor_count > 0 ? visitor_count - 1 : 0;
        ESP_LOGI(TAG, "Visitor Exited. Count: %d", visitor_count);
        update_display(visitor_count);
        
        mqtt_publish_count(visitor_count);
        mqtt_publish_event(MQTT_TOPIC_EXIT);
        
        exit_confirmed = true;
        exit_first = false;
        last_debounce_time = current_time;
    }
    
    // Reset states when both sensors are clear
    if (exit_state == 1 && entry_state == 1) {
        entry_first = false;
        exit_first = false;
        entry_confirmed = false;
        exit_confirmed = false;
    }
}