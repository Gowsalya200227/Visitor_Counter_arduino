#include "display.h"
#include "string.h"
#include "driver/gpio.h"

static const char *TAG = "DISPLAY";

// SSD1306 commands
#define SSD1306_SETCONTRAST 0x81
#define SSD1306_DISPLAYALLON_RESUME 0xA4
#define SSD1306_DISPLAYALLON 0xA5
#define SSD1306_NORMALDISPLAY 0xA6
#define SSD1306_INVERTDISPLAY 0xA7
#define SSD1306_DISPLAYOFF 0xAE
#define SSD1306_DISPLAYON 0xAF
#define SSD1306_SETDISPLAYOFFSET 0xD3
#define SSD1306_SETCOMPINS 0xDA
#define SSD1306_SETVCOMDETECT 0xDB
#define SSD1306_SETDISPLAYCLOCKDIV 0xD5
#define SSD1306_SETPRECHARGE 0xD9
#define SSD1306_SETMULTIPLEX 0xA8
#define SSD1306_SETLOWCOLUMN 0x00
#define SSD1306_SETHIGHCOLUMN 0x10
#define SSD1306_SETSTARTLINE 0x40
#define SSD1306_MEMORYMODE 0x20
#define SSD1306_COMSCANINC 0xC0
#define SSD1306_COMSCANDEC 0xC8
#define SSD1306_SEGREMAP 0xA0
#define SSD1306_CHARGEPUMP 0x8D

void i2c_master_init() {
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ,
    };
    i2c_param_config(I2C_MASTER_NUM, &conf);
    i2c_driver_install(I2C_MASTER_NUM, conf.mode, 0, 0, 0);
}

void ssd1306_write_command(uint8_t command) {
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, OLED_ADDRESS << 1 | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x00, true); // Command
    i2c_master_write_byte(cmd, command, true);
    i2c_master_stop(cmd);
    i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, 1000 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd);
}

void ssd1306_write_data(const uint8_t* data, size_t length) {
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, OLED_ADDRESS << 1 | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x40, true); // Data
    i2c_master_write(cmd, data, length, true);
    i2c_master_stop(cmd);
    i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, 1000 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd);
}

void display_init() {
    i2c_master_init();
    
    // Initialize SSD1306
    ssd1306_write_command(SSD1306_DISPLAYOFF);
    ssd1306_write_command(SSD1306_SETDISPLAYCLOCKDIV);
    ssd1306_write_command(0x80);
    ssd1306_write_command(SSD1306_SETMULTIPLEX);
    ssd1306_write_command(SCREEN_HEIGHT - 1);
    ssd1306_write_command(SSD1306_SETDISPLAYOFFSET);
    ssd1306_write_command(0x00);
    ssd1306_write_command(SSD1306_SETSTARTLINE | 0x00);
    ssd1306_write_command(SSD1306_CHARGEPUMP);
    ssd1306_write_command(0x14);
    ssd1306_write_command(SSD1306_MEMORYMODE);
    ssd1306_write_command(0x00);
    ssd1306_write_command(SSD1306_SEGREMAP | 0x01);
    ssd1306_write_command(SSD1306_COMSCANDEC);
    ssd1306_write_command(SSD1306_SETCOMPINS);
    ssd1306_write_command(0x12);
    ssd1306_write_command(SSD1306_SETCONTRAST);
    ssd1306_write_command(0xCF);
    ssd1306_write_command(SSD1306_SETPRECHARGE);
    ssd1306_write_command(0xF1);
    ssd1306_write_command(SSD1306_SETVCOMDETECT);
    ssd1306_write_command(0x40);
    ssd1306_write_command(SSD1306_DISPLAYALLON_RESUME);
    ssd1306_write_command(SSD1306_NORMALDISPLAY);
    ssd1306_write_command(SSD1306_DISPLAYON);
}

void display_clear() {
    uint8_t zero[SCREEN_WIDTH];
    memset(zero, 0, sizeof(zero));
    for (uint8_t i = 0; i < 8; i++) {
        ssd1306_write_command(0xB0 + i);
        ssd1306_write_command(0x00);
        ssd1306_write_command(0x10);
        ssd1306_write_data(zero, sizeof(zero));
    }
}

void display_draw_string(int x, int y, const char* text, int size) {
    // Simple implementation - draws block letters
    uint8_t buffer[SCREEN_WIDTH];
    memset(buffer, 0, sizeof(buffer));
    
    int pos = x;
    for (int i = 0; text[i] != '\0' && pos < SCREEN_WIDTH; i++) {
        // Simple block character (5x7)
        for (int j = 0; j < 5 && pos < SCREEN_WIDTH; j++) {
            buffer[pos++] = 0xFF;
        }
        pos++; // Space between characters
    }
    
    ssd1306_write_command(0xB0 + y);
    ssd1306_write_command(((x) & 0x0F) | 0x00);
    ssd1306_write_command((((x) >> 4) & 0x0F) | 0x10);
    ssd1306_write_data(buffer, sizeof(buffer));
}

void display_welcome_screen() {
    display_clear();
    display_draw_string(5, 0, "Visitor", 2);
    display_draw_string(5, 2, "Counter", 2);
}

void update_display(int visitor_count) {
    display_clear();
    char count_str[20];
    snprintf(count_str, sizeof(count_str), "Visitors: %d", visitor_count);
    display_draw_string(10, 2, count_str, 2);
    
    // Control LED
    gpio_set_level(LED_PIN, visitor_count > 0 ? 1 : 0);
}