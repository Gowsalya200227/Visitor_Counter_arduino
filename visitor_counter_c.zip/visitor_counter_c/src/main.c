#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "visitor_counter.h"
#include "wifi.h"
#include "mqtt.h"
#include "display.h"

void app_main() {
    // Initialize components
    display_init();
    display_welcome_screen();
    
    wifi_init_sta();
    mqtt_app_start();
    
    visitor_counter_init();
    
    while (1) {
        visitor_counter_update();
        vTaskDelay(50 / portTICK_PERIOD_MS);
    }
}