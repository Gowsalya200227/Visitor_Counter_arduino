# VerticalWritingDemo for SSD1306

![VerticalWritingDemo-1](https://github.com/user-attachments/assets/22aede1a-3fb3-4994-af52-0073a405377f)
![VerticalWritingDemo-2](https://github.com/user-attachments/assets/910b00d0-161b-4c7f-80f6-fc4eb6a308e7)

This demo is valid only for 128x64 panels.   
The maximum number of characters displayed in one line is 8 characters.   
