#ifndef WIFI_H
#define WIFI_H

void wifi_init_sta();

#endif // WIFI_H