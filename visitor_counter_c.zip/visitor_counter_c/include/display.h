#ifndef DISPLAY_H
#define DISPLAY_H

#include "config.h"
#include "driver/i2c.h"
#include "esp_log.h"

void display_init();
void display_welcome_screen();
void update_display(int visitor_count);
void display_clear();
void display_draw_string(int x, int y, const char* text, int size);

#endif // DISPLAY_H