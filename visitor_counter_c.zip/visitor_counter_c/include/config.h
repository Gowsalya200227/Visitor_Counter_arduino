#ifndef CONFIG_H
#define CONFIG_H

// OLED Display Configuration
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDRESS 0x3C

// IR Sensor and LED Pins
#define IR_SENSOR_ENTRY 5
#define IR_SENSOR_EXIT 4
#define LED_PIN 2

// WiFi Settings
#define WIFI_SSID "YourWiFiSSID"
#define WIFI_PASSWORD "YourWiFiPassword"

// MQTT Settings
#define MQTT_SERVER "broker.hivemq.com"
#define MQTT_PORT 1883
#define MQTT_CLIENT_ID "VisitorCounterESP32"
#define MQTT_TOPIC_COUNT "visitor-counter/count"
#define MQTT_TOPIC_ENTRY "visitor-counter/entry"
#define MQTT_TOPIC_EXIT "visitor-counter/exit"
#define MQTT_TOPIC_LED "visitor-counter/led"

// Timing constants
#define DEBOUNCE_DELAY 200
#define RECONNECT_INTERVAL 5000

// I2C Configuration
#define I2C_MASTER_SCL_IO 22
#define I2C_MASTER_SDA_IO 21
#define I2C_MASTER_NUM I2C_NUM_0
#define I2C_MASTER_FREQ_HZ 400000

// MQTT Settings
#define CONFIG_MQTT_BROKER_URL "mqtt://broker.hivemq.com"
#define CONFIG_MQTT_BROKER_PORT 1883
#define CONFIG_MQTT_CLIENT_ID "VisitorCounterESP32"

#endif // CONFIG_H

