#ifndef VISITOR_COUNTER_H
#define VISITOR_COUNTER_H

void visitor_counter_init();
void visitor_counter_update();

#endif // VISITOR_COUNTER_H