#ifndef MQTT_H
#define MQTT_H

#include "esp_event.h"
#include "esp_log.h"
#include "mqtt_client.h"

void mqtt_app_start();
void mqtt_publish_count(int count);
void mqtt_publish_event(const char* topic);

#endif // MQTT_H